
#ifndef BUTTON_H
#define BUTTON_H

#include "stm32l0xx_hal.h"

#define KEY_PIN				GPIOB->IDR
#define KEY5					5

#define REPEAT_MASK		(1<<KEY5)
#define REPEAT_START	100
#define REPEAT_NEXT		20

extern uint16_t key_state; 
extern uint16_t key_press;
extern uint16_t key_rpt;

void Key_Callback(void);
uint16_t get_key_press(uint16_t key_mask);
uint16_t get_key_rpt(uint16_t key_mask);
uint16_t get_key_short(uint16_t key_mask);
uint16_t get_key_long(uint16_t key_mask);

#endif // #ifndef KEYBOARD_H

