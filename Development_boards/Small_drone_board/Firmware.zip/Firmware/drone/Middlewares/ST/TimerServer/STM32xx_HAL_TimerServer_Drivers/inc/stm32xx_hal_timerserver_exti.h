/**
  ******************************************************************************
  * @file    stm32xx_hal_timerserver_exti.h
  * @author  MCD Application Team
  * @version V1.0.0
  * @date    01-October-2014
  * @brief   Header for stm32xx_timerserver.c module
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2014 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __STM32XX_HAL_TIMERSERVER_EXTI_H
#define __STM32XX_HAL_TIMERSERVER_EXTI_H

#ifdef __cplusplus
 extern "C" {
#endif

/** @addtogroup Middlewares
 *  @{
 */

/** @addtogroup ST
 *  @{
 */
 
/** @addtogroup TimerServer
 *  @{
 */

/** @defgroup STM32XX_HAL_TIMERSERVER_EXTI
 *  @{
 */
 
/* Includes ------------------------------------------------------------------*/
/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/

/** @defgroup STM32XX_HAL_TIMERSERVER_EXTI_Exported_Macros
 *  @{
 */
/* Exported macros -----------------------------------------------------------*/
 /**
   * @brief  Set Rising edge in EXTI for Wakeup Timer.
   * @param  None
   * @retval None
   */
#ifdef STM32L053xx
 #define __HAL_TIMERSERVER_EXTI_RTC_SET_WAKEUPTIMER_RISING_EDGE()   (EXTI->RTSR |= (RTC_EXTI_LINE_WAKEUPTIMER_EVENT))
#endif
 
#ifdef STM32L476xx
 #define __HAL_TIMERSERVER_EXTI_RTC_SET_WAKEUPTIMER_RISING_EDGE()   (EXTI->RTSR1 |= (RTC_EXTI_LINE_WAKEUPTIMER_EVENT))
#endif

#ifdef STM32F401xE
 #define __HAL_TIMERSERVER_EXTI_RTC_SET_WAKEUPTIMER_RISING_EDGE()   (EXTI->RTSR |= (RTC_EXTI_LINE_WAKEUPTIMER_EVENT))
#endif
   
/**
 * @}
 */
 
/* Exported functions ------------------------------------------------------- */

/**
 * @}
 */
 
/**
 * @}
 */
 
/**
 * @}
 */
 
/**
 * @}
 */

#ifdef __cplusplus
}
#endif

#endif /*__STM32XX_HAL_TIMERSERVER_EXTI_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
