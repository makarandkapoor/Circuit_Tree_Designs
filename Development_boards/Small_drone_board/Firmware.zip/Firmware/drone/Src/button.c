
#include "button.h"

uint16_t key_state; 
uint16_t key_press;
uint16_t key_rpt;

void Key_Callback(void)
{
	static uint16_t ct0, ct1, rpt;
	uint16_t i;
	
	i = key_state ^ ~KEY_PIN;					// Key Changed? 
	ct0 = ~( ct0 & i);
	ct1 = ct0 ^ (ct1 & i);
	i &= ct0 & ct1;
	key_state ^= i;
	key_press |= key_state & i;

	if( (key_state & REPEAT_MASK) == 0)
		rpt = REPEAT_START; 
	if (--rpt == 0) {
		rpt = REPEAT_NEXT;
		key_rpt |= key_state & REPEAT_MASK;
	}
}

uint16_t get_key_press(uint16_t key_mask)
{
	__disable_irq();
	key_mask &= key_press;
	key_press ^= key_mask;
	__enable_irq();
	return key_mask;
}

uint16_t get_key_rpt(uint16_t key_mask)
{
	__disable_irq();
	key_mask &= key_rpt;
	key_rpt ^= key_mask;
	__enable_irq();
	return key_mask;
}

uint16_t get_key_short(uint16_t key_mask)
{
	__disable_irq();
	return get_key_press(~key_state & key_mask);
}

uint16_t get_key_long(uint16_t key_mask)
{
	__disable_irq();
	return get_key_press(get_key_rpt(key_mask));
}
