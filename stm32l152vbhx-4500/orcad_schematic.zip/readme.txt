Steps to import the edif file into Cadence Orcad EDA Tool:

1. Unzip the files to local directory and start Orcad EDA tool.
2. From Menu select File\Import Design and select the EDIF tab.
3. Direct the import menu to the downloaded file folder and press import design.
4. Use File\Open\Design from the menu to view your Schematic.

